# MOZ MARKET 🇲🇿

Mobile marketplace prototype for Mozambique.

Files:
- `pubspec.yaml` — Flutter dependencies
- `main.dart` — app code (moved to `lib/main.dart` during cloud build)
- `codemagic.yaml` — automatically creates the Android project and builds the APK

This is a prototype. Real login, database, photo upload, chat, payments, moderation and admin tools are not yet connected.
