import 'package:flutter/material.dart';

void main() => runApp(const MozMarketApp());

class MozMarketApp extends StatelessWidget {
  const MozMarketApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MOZ MARKET',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.green),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  final search = TextEditingController();
  final categories = ['Clothes','Shoes & Bags','Phones','Electronics','Cars','Furniture','Jobs','Services'];
  final products = [
    ['iPhone 13 Pro','45,000 MZN','Maputo'],
    ['Men T-Shirt','500 MZN','Matola'],
    ['Laptop Dell','28,000 MZN','Maputo'],
  ];

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(context),
      _simple('My Ads', Icons.inventory_2_outlined),
      _simple('Messages', Icons.chat_bubble_outline),
      _simple('Profile', Icons.person_outline),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('MOZ MARKET 🇲🇿', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none))],
      ),
      body: pages[tab],
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _postAd(context),
        icon: const Icon(Icons.add),
        label: const Text('Post Ad'),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'My Ads'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Chat'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _home(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        TextField(
          controller: search,
          decoration: InputDecoration(
            hintText: 'Search / Procurar...',
            prefixIcon: const Icon(Icons.search),
            filled: true,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: Colors.green.shade50),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Buy & Sell Anything', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 6),
            Text('Compre e venda facilmente em Moçambique 🇲🇿'),
          ]),
        ),
        const SizedBox(height: 18),
        const Text('Categories / Categorias', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8, runSpacing: 8,
          children: categories.map((c) => ActionChip(label: Text(c), onPressed: () {})).toList(),
        ),
        const SizedBox(height: 22),
        const Text('Featured Ads / Destaques', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        ...products.map((p) => Card(
          child: ListTile(
            leading: Container(width: 54, height: 54, decoration: BoxDecoration(color: Colors.grey.shade200, borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.image_outlined)),
            title: Text(p[0], style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('${p[1]} • ${p[2]}'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _product(context, p),
          ),
        )),
      ],
    );
  }

  Widget _simple(String title, IconData icon) => Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
    Icon(icon, size: 64), const SizedBox(height: 12), Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold))
  ]));

  void _postAd(BuildContext context) {
    final name = TextEditingController();
    final price = TextEditingController();
    showModalBottomSheet(
      context: context, isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: MediaQuery.of(context).viewInsets.bottom + 20),
        child: Wrap(children: [
          const Text('Post a New Ad / Publicar anúncio', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          TextField(controller: name, decoration: const InputDecoration(labelText: 'Product / Produto', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Price (MZN) / Preço', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          const ListTile(leading: Icon(Icons.photo_camera_outlined), title: Text('Add photos / Adicionar fotos')),
          const ListTile(leading: Icon(Icons.location_on_outlined), title: Text('Location / Localização')),
          const SizedBox(height: 8),
          SizedBox(width: double.infinity, child: FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Publish / Publicar'))),
        ]),
      ),
    );
  }

  void _product(BuildContext context, List<String> p) {
    showDialog(context: context, builder: (_) => AlertDialog(
      title: Text(p[0]),
      content: Text('Price: ${p[1]}\nLocation: ${p[2]}\n\nContact the seller to make a deal.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
        FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Chat Seller')),
      ],
    ));
  }
}
