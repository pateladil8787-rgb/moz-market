import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:geolocator/geolocator.dart';

void main() => runApp(const MozMarketApp());

class MozMarketApp extends StatelessWidget {
  const MozMarketApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MOZ MARKET',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2E7D32)),
        scaffoldBackgroundColor: const Color(0xFFF8FAF3),
      ),
      home: const HomePage(),
    );
  }
}

class Ad {
  final String title, price, location, category, description;
  final List<XFile> photos;
  Ad({
    required this.title,
    required this.price,
    required this.location,
    required this.category,
    required this.description,
    required this.photos,
  });
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  final List<Ad> ads = [
    Ad(title: 'iPhone 13 Pro', price: '45,000 MZN', location: 'Maputo',
        category: 'Phones', description: 'Good condition', photos: []),
    Ad(title: 'Men T-Shirt', price: '500 MZN', location: 'Matola',
        category: 'Clothes', description: 'Good condition', photos: []),
    Ad(title: 'Laptop Dell', price: '30,000 MZN', location: 'Maputo',
        category: 'Laptops / Computers', description: 'Good condition', photos: []),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('MOZ MARKET 🇲🇿',
            style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none))],
      ),
      body: tab == 0
          ? _home()
          : tab == 1
              ? _myAds()
              : tab == 2
                  ? const Center(child: Text('Chat / Conversas',
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)))
                  : const Center(child: Text('Profile / Perfil',
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
      floatingActionButton: tab == 0
          ? FloatingActionButton.extended(
              onPressed: _showPostAd,
              icon: const Icon(Icons.add),
              label: const Text('Post Ad'),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'My Ads'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Chat'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _home() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 100),
      children: [
        TextField(
          decoration: InputDecoration(
            hintText: 'Search / Procurar...',
            prefixIcon: const Icon(Icons.search),
            filled: true,
            fillColor: const Color(0xFFE4E7DF),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
          ),
        ),
        const SizedBox(height: 28),
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: const Color(0xFFE8F5E9),
            borderRadius: BorderRadius.circular(28),
          ),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Buy & Sell Anything', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
            SizedBox(height: 10),
            Text('Compre e venda facilmente em Moçambique 🇲🇿', style: TextStyle(fontSize: 16)),
          ]),
        ),
        const SizedBox(height: 28),
        const Text('Categories / Categorias', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        const SizedBox(height: 14),
        Wrap(
          spacing: 10, runSpacing: 10,
          children: ['Clothes','Shoes & Bags','Phones','Electronics','Laptops / Computers','TV / Appliances','Gaming','Cars / Bikes','Furniture','Jobs','Services','Other']
              .map((c) => OutlinedButton(onPressed: () {}, child: Text(c))).toList(),
        ),
        const SizedBox(height: 30),
        const Text('Featured Ads / Destaques', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        ...ads.map(_adCard),
      ],
    );
  }

  Widget _adCard(Ad ad) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        contentPadding: const EdgeInsets.all(10),
        leading: ad.photos.isNotEmpty
            ? ClipRRect(borderRadius: BorderRadius.circular(10),
                child: Image.file(File(ad.photos.first.path), width: 62, height: 62, fit: BoxFit.cover))
            : Container(width: 62, height: 62, decoration: BoxDecoration(
                color: Colors.grey.shade100, borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.image_outlined, size: 30)),
        title: Text(ad.title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text('${ad.price} • ${ad.location}\n${ad.category}'),
        isThreeLine: true,
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }

  Widget _myAds() {
    final mine = ads.length > 3 ? ads.sublist(3) : <Ad>[];
    return mine.isEmpty
        ? const Center(child: Text('Your ads will appear here.\nPost your first ad!',
            textAlign: TextAlign.center, style: TextStyle(fontSize: 18)))
        : ListView(padding: const EdgeInsets.all(16), children: mine.map(_adCard).toList());
  }

  Future<void> _showPostAd() async {
    final title = TextEditingController();
    final price = TextEditingController();
    final description = TextEditingController();
    String category = 'Clothes';
    String location = '';
    List<XFile> photos = [];

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setModalState) {
        Future<void> pickPhotos() async {
          final picked = await ImagePicker().pickMultiImage(imageQuality: 80);
          if (picked.isNotEmpty) setModalState(() => photos = picked);
        }

        Future<void> getLocation() async {
          try {
            bool enabled = await Geolocator.isLocationServiceEnabled();
            if (!enabled) {
              if (ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(
                const SnackBar(content: Text('Please turn on Location/GPS first.')));
              return;
            }
            LocationPermission permission = await Geolocator.checkPermission();
            if (permission == LocationPermission.denied) {
              permission = await Geolocator.requestPermission();
            }
            if (permission == LocationPermission.denied ||
                permission == LocationPermission.deniedForever) {
              if (ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(
                const SnackBar(content: Text('Location permission was not granted.')));
              return;
            }
            final p = await Geolocator.getCurrentPosition();
            setModalState(() => location =
                'GPS: ${p.latitude.toStringAsFixed(5)}, ${p.longitude.toStringAsFixed(5)}');
          } catch (e) {
            if (ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(
              SnackBar(content: Text('Could not get location: $e')));
          }
        }

        return Padding(
          padding: EdgeInsets.only(
            left: 20, right: 20, top: 18,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 16,
          ),
          child: SingleChildScrollView(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Post a New Ad / Publicar anúncio',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              TextField(controller: title, decoration: const InputDecoration(
                labelText: 'Product / Produto', border: OutlineInputBorder())),
              const SizedBox(height: 10),
              TextField(controller: price, keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Price (MZN) / Preço', border: OutlineInputBorder())),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: category,
                decoration: const InputDecoration(labelText: 'Category / Categoria', border: OutlineInputBorder()),
                items: ['Clothes','Shoes & Bags','Phones','Electronics','Laptops / Computers','TV / Appliances','Gaming','Cars / Bikes','Furniture','Jobs','Services','Other']
                    .map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                onChanged: (v) => setModalState(() => category = v ?? category),
              ),
              const SizedBox(height: 10),
              TextField(controller: description, maxLines: 3, decoration: const InputDecoration(
                labelText: 'Description / Descrição', border: OutlineInputBorder())),
              const SizedBox(height: 14),
              OutlinedButton.icon(
                onPressed: pickPhotos,
                icon: const Icon(Icons.photo_camera_outlined),
                label: Text(photos.isEmpty ? 'Add photos / Adicionar fotos' : '${photos.length} photo(s) selected'),
              ),
              if (photos.isNotEmpty) ...[
                const SizedBox(height: 8),
                SizedBox(height: 82, child: ListView.separated(
                  scrollDirection: Axis.horizontal, itemCount: photos.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (_, i) => ClipRRect(borderRadius: BorderRadius.circular(10),
                    child: Image.file(File(photos[i].path), width: 82, height: 82, fit: BoxFit.cover)),
                )),
              ],
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: getLocation,
                icon: const Icon(Icons.location_on_outlined),
                label: Text(location.isEmpty ? 'Use my location / Minha localização' : location),
              ),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, child: FilledButton(
                onPressed: () {
                  if (title.text.trim().isEmpty || price.text.trim().isEmpty) {
                    ScaffoldMessenger.of(ctx).showSnackBar(
                      const SnackBar(content: Text('Enter product and price first.')));
                    return;
                  }
                  setState(() {
                    ads.add(Ad(
                      title: title.text.trim(),
                      price: '${price.text.trim()} MZN',
                      location: location.isEmpty ? 'Not specified' : location,
                      category: category,
                      description: description.text.trim(),
                      photos: photos,
                    ));
                    tab = 1;
                  });
                  Navigator.pop(ctx);
                },
                child: const Text('Publish / Publicar'),
              )),
            ]),
          ),
        );
      }),
    );
  }
}
