# MOZ MARKET V2 🇲🇿

Phone-friendly Flutter prototype.

V2 adds:
- Real gallery photo selection
- Photo preview
- GPS location button
- Category selection
- Description field
- Published ads shown in My Ads
- Updated app version 1.1.0
